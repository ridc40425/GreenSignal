export default async function handler(req, res) {
  // CORS headers
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") return res.status(200).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "Server not configured. Set ANTHROPIC_API_KEY in Vercel environment variables." });
  }

  const today = new Date().toISOString().split("T")[0];

  const prompt = `Today is ${today}. Use your web search tool to find the TOP 5 genuinely positive and significant news stories from TODAY or the past 48 hours about humanity's progress on sustainability and climate change.

Focus on real, verifiable stories: renewable energy milestones, policy wins, conservation breakthroughs, technology advances, corporate pledges met, rewilding successes, ocean recovery, clean transport, green finance, etc.

After searching, respond ONLY with a valid JSON object (no markdown, no backticks, no extra text) in exactly this format:
{
  "stories": [
    {
      "rank": 1,
      "headline": "Short punchy headline (max 12 words)",
      "category": "One of: Renewable Energy / Policy & Law / Conservation / Clean Tech / Ocean & Nature / Agriculture / Transport / Finance",
      "summary": "2-3 sentences. What happened, why it matters, what it means for the future. Uplifting and factual.",
      "source": "Publication name",
      "url": "Full URL if available, else empty string",
      "impact_score": 85,
      "region": "e.g. Global / Europe / USA / Asia / Africa / Latin America"
    }
  ],
  "editors_note": "One elegant 2-sentence reflection on what these five stories collectively signal about the direction humanity is heading."
}

impact_score is 1-100 (your honest assessment of planetary significance).
Aim for diverse categories and regions across the 5 stories.`;

  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 3000,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: data.error?.message || "Upstream API error" });
    }

    // Extract text blocks and parse JSON
    const text = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    const match = text.match(/\{[\s\S]*"stories"[\s\S]*\}/);
    if (!match) {
      return res.status(500).json({ error: "Could not parse stories from AI response." });
    }

    const parsed = JSON.parse(match[0]);
    return res.status(200).json(parsed);

  } catch (err) {
    return res.status(500).json({ error: err.message || "Unexpected server error" });
  }
}
