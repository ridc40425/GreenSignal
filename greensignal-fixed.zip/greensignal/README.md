# 🌿 Terrain — Sustainability Good News

A beautiful, editorial-style web app that uses Claude AI + live web search to surface the top 5 sustainability and climate good-news stories every day. No login, no API key required for visitors.

---

## Project Structure

```
terrain/
├── api/
│   └── news.js          ← Serverless function (your API key lives here, securely)
├── public/
│   └── index.html       ← The full frontend app
├── vercel.json          ← Routing config
└── README.md
```

---

## Deploy to Vercel (5 minutes)

### Step 1 — Get your Anthropic API key
1. Go to [console.anthropic.com](https://console.anthropic.com)
2. Sign in → **API Keys** → **Create Key**
3. Copy it (starts with `sk-ant-...`)

### Step 2 — Deploy to Vercel

**Option A: Via GitHub (recommended)**
1. Push this folder to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → **Add New Project** → Import your repo
3. Leave all settings as default → click **Deploy**

**Option B: Via Vercel CLI**
```bash
npm install -g vercel
cd terrain
vercel
```

### Step 3 — Add your API key as an environment variable
1. In your Vercel dashboard → your project → **Settings** → **Environment Variables**
2. Add:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-your-key-here`
   - **Environments:** Production, Preview, Development ✓
3. Click **Save**
4. Go to **Deployments** → **Redeploy** (so the new env var takes effect)

### Step 4 — Share your URL 🎉
Vercel gives you a URL like `terrain-xyz.vercel.app`. Share it freely — visitors need no account or API key.

---

## How it works

1. User visits your site and clicks "Scan Today's News"
2. The browser calls **your** `/api/news` endpoint on Vercel
3. Your serverless function (with your secret API key) calls Anthropic
4. Claude uses live web search to find today's top 5 sustainability stories
5. Stories are returned and rendered in the editorial layout

**Your API key is never exposed to visitors.**

---

## Costs

- **Vercel hosting:** Free (Hobby plan)
- **Anthropic API:** ~$0.01–0.03 per search (Claude Sonnet + web search)
- Each button click = one API call

To protect against abuse, consider adding [Vercel's Rate Limiting](https://vercel.com/docs/security/rate-limiting) or a simple daily cache.

---

## Optional: Cache results daily (save API costs)

Add this to `api/news.js` to cache the result for 24 hours using Vercel's edge cache:

```js
// At the top of the handler, after setting CORS headers:
res.setHeader('Cache-Control', 's-maxage=86400, stale-while-revalidate');
```

This means the first visitor each day triggers a real API call; everyone else gets the cached result instantly.
